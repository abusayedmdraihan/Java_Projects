package Xml;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Scanner;

public class RenameAsset {
	static {
		try {
			main(new String[] {"Hello"});
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) throws InterruptedException
	{
		
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter File Path:");
		String FilePath = sc.nextLine();
		System.out.println("\nEnter Source Asset Name:");
		String AssetName = sc.nextLine();
		System.out.println("\nEnter Source Asset extention:");
		String AssetExt = sc.nextLine();
		List<String> AssetextenstionType = List.of("TIF", "PDF", "JPG", "tif", "pdf", "jpg");
		if (AssetextenstionType.contains(AssetExt)) {
			System.out.println("\nEnter Prefix of Part No:");
			String PartNo = sc.nextLine();
			System.out.println("\nEnter PIESCount:");
			int PIESCount = sc.nextInt();
			for (int i = 1; i < PIESCount + 1; i++) {
				File oldFile = new File(FilePath + "\\" + AssetName + "." + AssetExt);
				File newFile = new File(FilePath + "\\" + PartNo + i + "." + AssetExt.toLowerCase());
				try {
					copyFileUsingJava7Files(oldFile, newFile);
					
				} catch (IOException e) {
					//e.printStackTrace();
					System.out.println("\n*****"+PartNo + i +" is alreday Exists with Same Name!!!!*****");
				}
			}
			System.out.println("\n*****Asset rename Task Complete*****\n");
			
		}
		else {
			System.out.println("\n*****Invalid Asset Extention!!!!*****");
			
		}
		Thread.sleep(1000);
		
	}
	
	private static void copyFileUsingJava7Files(File source, File dest) throws IOException {
		Files.copy(source.toPath(), dest.toPath());
	}
	

}