package Xml;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class XMLCreatorWithFourteenZeros {
	public static void main(String argv[]) {

		String PartNo = null;
		String ImageExt = null;
		int PIESCount = 0;
		int RETPrice, ZZ1Price, ZZ2Price = 0, CRGPrice = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("\nEnter Prefix of Part No:");
		PartNo = sc.nextLine();
		System.out.println("\nEnter Image extention:");
		ImageExt = sc.nextLine();
		System.out.println("\nDo you want to add Core and Base Price:\n If NO Please type N and for YES type Y:");
		String coreBaseCost = sc.nextLine();
		if (coreBaseCost.equalsIgnoreCase("N")) {
			System.out.println("\nEnter RET Price:");
			RETPrice = sc.nextInt();
			System.out.println("\nEnter ZZ1 Price:");
			ZZ1Price = sc.nextInt();
		} else {
			System.out.println("\nEnter RET Price:");
			RETPrice = sc.nextInt();
			System.out.println("\nEnter ZZ1 Price:");
			ZZ1Price = sc.nextInt();
			System.out.println("\nEnter ZZ2 Price:");
			ZZ2Price = sc.nextInt();
			System.out.println("\nEnter CRG Price:");
			CRGPrice = sc.nextInt();
		}
		
		String PIESdic=System.getProperty("user.dir");
		System.out.println("\nPlease type folder name to store PIES files:");
		
		 PIESdic = PIESdic+sc.next();  
	      //Instantiate the File class   
	      File f1 = new File(PIESdic);     
	      //Creating a folder using mkdirs() method  
	      boolean bool2 = f1.mkdirs();
		

		// ImageExt=ImageExt.toLowerCase();
		System.out.println("\nPlease ensure package count:");
		int PackageCount = sc.nextInt();

		// System.out.println("Enter ZZ1 Price:\n");

		
		String packtype = null;
		ArrayList<String> packlist = new ArrayList<String>();
		
		System.out.println("Please ensure package type:");
		
		for (int k = 0; k < PackageCount + 1; k++) {
			packtype = sc.nextLine();
			packlist.add(packtype.toUpperCase());
			
		}
		
		
		
		
		System.out.println("Enter PIESCount:\n");
		PIESCount = sc.nextInt();

		List<String> AssetextenstionType = List.of("TIF", "PDF", "JPG", "tif", "pdf", "jpg");
		List<String> packTypeList=List.of("EA","CA");
		if (AssetextenstionType.contains(ImageExt) && RETPrice > ZZ1Price && packlist.contains("EA") && packTypeList.contains(packtype) ) {

			// sc.close();
			for (int i = 1; i < PIESCount + 1; i++) {

				try {
					DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
					Document doc = dBuilder.newDocument();
					doc.setXmlVersion("1.0");
					doc.setXmlStandalone(true);

					// root element doc
					Element PIES = doc.createElement("PIES");
					Attr xmlns = doc.createAttribute("xmlns:xsi");
					xmlns.setValue("http://www.w3.org/2001/XMLSchema-instance");
					PIES.setAttributeNode(xmlns);
					Attr xmlns2 = doc.createAttribute("xmlns");
					xmlns2.setValue("http://www.autocare.org");
					PIES.setAttributeNode(xmlns2);
					doc.appendChild(PIES);

					// Header Element
					Element Header = doc.createElement("Header");
					PIES.appendChild(Header);

					// Header Element
					Element PIESVersion = doc.createElement("PIESVersion");
					PIESVersion.appendChild(doc.createTextNode("7.0"));
					Header.appendChild(PIESVersion);

					Element SubmissionType = doc.createElement("SubmissionType");
					SubmissionType.appendChild(doc.createTextNode("FULL"));
					Header.appendChild(SubmissionType);

					Element BlanketEffectiveDate = doc.createElement("BlanketEffectiveDate");
					BlanketEffectiveDate.appendChild(doc.createTextNode("2011-08-26"));
					Header.appendChild(BlanketEffectiveDate);

					Element ParentAAIAID = doc.createElement("ParentAAIAID");
					ParentAAIAID.appendChild(doc.createTextNode("BFLM"));
					Header.appendChild(ParentAAIAID);

					Element BrandOwnerAAIAID = doc.createElement("BrandOwnerAAIAID");
					BrandOwnerAAIAID.appendChild(doc.createTextNode("BFLM"));
					Header.appendChild(BrandOwnerAAIAID);

					Element TechnicalContact = doc.createElement("TechnicalContact");
					TechnicalContact.appendChild(doc.createTextNode("paul hollstein"));
					Header.appendChild(TechnicalContact);

					Element ContactEmail = doc.createElement("ContactEmail");
					ContactEmail.appendChild(doc.createTextNode("phollstein@melling.com"));
					Header.appendChild(ContactEmail);

					// Items
					Element Items = doc.createElement("Items");
					PIES.appendChild(Items);

					Element Item = doc.createElement("Item");
					Attr MaintenanceType = doc.createAttribute("MaintenanceType");
					MaintenanceType.setValue("A");
					Item.setAttributeNode(MaintenanceType);
					Items.appendChild(Item);

					Element HazardousMaterialCode = doc.createElement("HazardousMaterialCode");
					HazardousMaterialCode.appendChild(doc.createTextNode("N"));
					Item.appendChild(HazardousMaterialCode);

					Element ItemLevelGTIN = doc.createElement("ItemLevelGTIN");
					Attr GTINQualifier = doc.createAttribute("GTINQualifier");
					GTINQualifier.setValue("UP");
					ItemLevelGTIN.setAttributeNode(GTINQualifier);
					ItemLevelGTIN.appendChild(doc.createTextNode("00000000000000"));
					Item.appendChild(ItemLevelGTIN);

					Element PartNumber = doc.createElement("PartNumber");
					PartNumber.appendChild(doc.createTextNode(PartNo + i));
					Item.appendChild(PartNumber);

					Element BrandAAIAID = doc.createElement("BrandAAIAID");
					BrandAAIAID.appendChild(doc.createTextNode("BBBB"));
					Item.appendChild(BrandAAIAID);

					Element BrandLabel = doc.createElement("BrandLabel");
					BrandLabel.appendChild(doc.createTextNode("BWP"));
					Item.appendChild(BrandLabel);

					Element QuantityPerApplication = doc.createElement("QuantityPerApplication");
					Attr Qualifier = doc.createAttribute("Qualifier");
					Qualifier.setValue("NOR");
					QuantityPerApplication.setAttributeNode(Qualifier);
					Attr UOM = doc.createAttribute("UOM");
					UOM.setValue("EA");
					QuantityPerApplication.setAttributeNode(UOM);
					QuantityPerApplication.appendChild(doc.createTextNode("1"));
					Item.appendChild(QuantityPerApplication);

					Element ItemEffectiveDate = doc.createElement("ItemEffectiveDate");
					ItemEffectiveDate.appendChild(doc.createTextNode("2016-08-25"));
					Item.appendChild(ItemEffectiveDate);

					Element AvailableDate = doc.createElement("AvailableDate");
					AvailableDate.appendChild(doc.createTextNode("2016-08-25"));
					Item.appendChild(AvailableDate);

					Element MinimumOrderQuantity = doc.createElement("MinimumOrderQuantity");
					Attr UOM2 = doc.createAttribute("UOM");
					UOM2.setValue("EA");
					MinimumOrderQuantity.setAttributeNode(UOM2);
					MinimumOrderQuantity.appendChild(doc.createTextNode("1"));
					Item.appendChild(MinimumOrderQuantity);

					Element PartTerminologyID = doc.createElement("PartTerminologyID");
					PartTerminologyID.appendChild(doc.createTextNode("14364"));
					Item.appendChild(PartTerminologyID);

					Element Descriptions = doc.createElement("Descriptions");
					Item.appendChild(Descriptions);

					Element Description = doc.createElement("Description");
					Attr MaintenanceType1 = doc.createAttribute("MaintenanceType");
					MaintenanceType1.setValue("A");
					Description.setAttributeNode(MaintenanceType1);
					Attr DescriptionCode = doc.createAttribute("DescriptionCode");
					DescriptionCode.setValue("ABR");
					Description.setAttributeNode(DescriptionCode);
					Attr LanguageCode = doc.createAttribute("LanguageCode");
					LanguageCode.setValue("EN");
					Description.setAttributeNode(LanguageCode);

					Description.appendChild(doc.createTextNode("ABR on Oil Pump"));
					Descriptions.appendChild(Description);

					Element Description2 = doc.createElement("Description");
					Attr MaintenanceType2 = doc.createAttribute("MaintenanceType");
					MaintenanceType2.setValue("A");
					Description2.setAttributeNode(MaintenanceType2);
					Attr DescriptionCode2 = doc.createAttribute("DescriptionCode");
					DescriptionCode2.setValue("DES");
					Description2.setAttributeNode(DescriptionCode2);
					Attr LanguageCode2 = doc.createAttribute("LanguageCode");
					LanguageCode2.setValue("EN");
					Description2.setAttributeNode(LanguageCode2);

					Description2.appendChild(doc.createTextNode("DES LONG on Oil Pump"));
					Descriptions.appendChild(Description2);

					Element Description3 = doc.createElement("Description");
					Attr MaintenanceType3 = doc.createAttribute("MaintenanceType");
					MaintenanceType3.setValue("A");
					Description3.setAttributeNode(MaintenanceType3);
					Attr DescriptionCode3 = doc.createAttribute("DescriptionCode");
					DescriptionCode3.setValue("DEF");
					Description3.setAttributeNode(DescriptionCode3);
					Attr LanguageCode3 = doc.createAttribute("LanguageCode");
					LanguageCode3.setValue("EN");
					Description3.setAttributeNode(LanguageCode3);

					Description3.appendChild(doc.createTextNode("DEF Engine Oil Pump"));
					Descriptions.appendChild(Description3);

					Element Description4 = doc.createElement("Description");
					Attr MaintenanceType4 = doc.createAttribute("MaintenanceType");
					MaintenanceType4.setValue("A");
					Description4.setAttributeNode(MaintenanceType4);
					Attr DescriptionCode4 = doc.createAttribute("DescriptionCode");
					DescriptionCode4.setValue("EXT");
					Description4.setAttributeNode(DescriptionCode4);
					Attr LanguageCode4 = doc.createAttribute("LanguageCode");
					LanguageCode4.setValue("EN");
					Description4.setAttributeNode(LanguageCode4);

					Description4.appendChild(doc.createTextNode("EXT OIL PUMP"));
					Descriptions.appendChild(Description4);

					Element Description5 = doc.createElement("Description");
					Attr MaintenanceType5 = doc.createAttribute("MaintenanceType");
					MaintenanceType5.setValue("A");
					Description5.setAttributeNode(MaintenanceType5);
					Attr DescriptionCode5 = doc.createAttribute("DescriptionCode");
					DescriptionCode5.setValue("KEY");
					Description5.setAttributeNode(DescriptionCode5);
					Attr LanguageCode5 = doc.createAttribute("LanguageCode");
					LanguageCode5.setValue("EN");
					Description5.setAttributeNode(LanguageCode5);

					Description5.appendChild(doc.createTextNode("KEY Words on Oil Pump"));
					Descriptions.appendChild(Description5);

					Element Description6 = doc.createElement("Description");
					Attr MaintenanceType6 = doc.createAttribute("MaintenanceType");
					MaintenanceType6.setValue("A");
					Description6.setAttributeNode(MaintenanceType6);
					Attr DescriptionCode6 = doc.createAttribute("DescriptionCode");
					DescriptionCode6.setValue("MKT");
					Description6.setAttributeNode(DescriptionCode6);
					Attr LanguageCode6 = doc.createAttribute("LanguageCode");
					LanguageCode6.setValue("EN");
					Description6.setAttributeNode(LanguageCode6);

					Description6.appendChild(doc.createTextNode("Marketing Descripton"));
					Descriptions.appendChild(Description6);

					Element Description7 = doc.createElement("Description");
					Attr MaintenanceType7 = doc.createAttribute("MaintenanceType");
					MaintenanceType7.setValue("A");
					Description7.setAttributeNode(MaintenanceType7);
					Attr DescriptionCode7 = doc.createAttribute("DescriptionCode");
					DescriptionCode7.setValue("SHO");
					Description7.setAttributeNode(DescriptionCode7);
					Attr LanguageCode7 = doc.createAttribute("LanguageCode");
					LanguageCode7.setValue("EN");
					Description7.setAttributeNode(LanguageCode7);

					Description7.appendChild(doc.createTextNode("Short Oil Pump"));
					Descriptions.appendChild(Description7);

					Element Description8 = doc.createElement("Description");
					Attr MaintenanceType8 = doc.createAttribute("MaintenanceType");
					MaintenanceType8.setValue("A");
					Description8.setAttributeNode(MaintenanceType8);
					Attr DescriptionCode8 = doc.createAttribute("DescriptionCode");
					DescriptionCode8.setValue("INV");
					Description8.setAttributeNode(DescriptionCode8);
					Attr LanguageCode8 = doc.createAttribute("LanguageCode");
					LanguageCode8.setValue("EN");
					Description8.setAttributeNode(LanguageCode8);

					Description8.appendChild(doc.createTextNode("Inventory Big Oil Pump"));
					Descriptions.appendChild(Description8);

					Element Description9 = doc.createElement("Description");
					Attr MaintenanceType9 = doc.createAttribute("MaintenanceType");
					MaintenanceType9.setValue("A");
					Description9.setAttributeNode(MaintenanceType9);
					Attr DescriptionCode9 = doc.createAttribute("DescriptionCode");
					DescriptionCode9.setValue("SHP");
					Description9.setAttributeNode(DescriptionCode9);
					Attr LanguageCode9 = doc.createAttribute("LanguageCode");
					LanguageCode9.setValue("EN");
					Description9.setAttributeNode(LanguageCode9);

					Description9.appendChild(doc.createTextNode("Shipping on Sleek Oil Pump"));
					Descriptions.appendChild(Description9);

					Element Description10 = doc.createElement("Description");
					Attr MaintenanceType10 = doc.createAttribute("MaintenanceType");
					MaintenanceType10.setValue("A");
					Description10.setAttributeNode(MaintenanceType10);
					Attr DescriptionCode10 = doc.createAttribute("DescriptionCode");
					DescriptionCode10.setValue("SLA");
					Description10.setAttributeNode(DescriptionCode10);
					Attr LanguageCode10 = doc.createAttribute("LanguageCode");
					LanguageCode10.setValue("EN");
					Description10.setAttributeNode(LanguageCode10);

					Description10.appendChild(doc.createTextNode("Blue Oil Pump"));
					Descriptions.appendChild(Description10);

					Element Description11 = doc.createElement("Description");
					Attr MaintenanceType11 = doc.createAttribute("MaintenanceType");
					MaintenanceType11.setValue("A");
					Description11.setAttributeNode(MaintenanceType11);
					Attr DescriptionCode11 = doc.createAttribute("DescriptionCode");
					DescriptionCode11.setValue("VMR");
					Description11.setAttributeNode(DescriptionCode11);
					Attr LanguageCode11 = doc.createAttribute("LanguageCode");
					LanguageCode11.setValue("EN");
					Description11.setAttributeNode(LanguageCode11);

					Description11.appendChild(doc.createTextNode("Very Very Blue Oil Pump"));
					Descriptions.appendChild(Description11);

					Element Description12 = doc.createElement("Description");
					Attr MaintenanceType12 = doc.createAttribute("MaintenanceType");
					MaintenanceType12.setValue("A");
					Description12.setAttributeNode(MaintenanceType12);
					Attr DescriptionCode12 = doc.createAttribute("DescriptionCode");
					DescriptionCode12.setValue("CAP");
					Description12.setAttributeNode(DescriptionCode12);
					Attr LanguageCode12 = doc.createAttribute("LanguageCode");
					LanguageCode12.setValue("EN");
					Description12.setAttributeNode(LanguageCode12);

					Description12.appendChild(doc.createTextNode("Vinegar Oil Pump"));
					Descriptions.appendChild(Description12);

					Element Description13 = doc.createElement("Description");
					Attr MaintenanceType13 = doc.createAttribute("MaintenanceType");
					MaintenanceType13.setValue("A");
					Description13.setAttributeNode(MaintenanceType13);
					Attr DescriptionCode13 = doc.createAttribute("DescriptionCode");
					DescriptionCode13.setValue("TRA");
					Description13.setAttributeNode(DescriptionCode13);
					Attr LanguageCode13 = doc.createAttribute("LanguageCode");
					LanguageCode13.setValue("EN");
					Description13.setAttributeNode(LanguageCode13);

					Description13.appendChild(doc.createTextNode("Happy Oil Pump"));
					Descriptions.appendChild(Description13);

					Element Description14 = doc.createElement("Description");
					Attr MaintenanceType14 = doc.createAttribute("MaintenanceType");
					MaintenanceType14.setValue("A");
					Description14.setAttributeNode(MaintenanceType14);
					Attr DescriptionCode14 = doc.createAttribute("DescriptionCode");
					DescriptionCode14.setValue("TLE");
					Description14.setAttributeNode(DescriptionCode14);
					Attr LanguageCode14 = doc.createAttribute("LanguageCode");
					LanguageCode14.setValue("EN");
					Description14.setAttributeNode(LanguageCode14);

					Description14.appendChild(doc.createTextNode("Sper Oil Pump"));
					Descriptions.appendChild(Description14);

					Element DescriptionX = doc.createElement("Description");
					Attr MaintenanceTypeX = doc.createAttribute("MaintenanceType");
					MaintenanceTypeX.setValue("A");
					DescriptionX.setAttributeNode(MaintenanceTypeX);
					Attr DescriptionCodeX = doc.createAttribute("DescriptionCode");
					DescriptionCodeX.setValue("UNS");
					DescriptionX.setAttributeNode(DescriptionCodeX);
					Attr LanguageCodeX = doc.createAttribute("LanguageCode");
					LanguageCodeX.setValue("EN");
					DescriptionX.setAttributeNode(LanguageCodeX);

					DescriptionX.appendChild(doc.createTextNode("UNSPSC Sper Oil Pump"));
					Descriptions.appendChild(DescriptionX);

					Element Description15 = doc.createElement("Description");
					Attr MaintenanceType15 = doc.createAttribute("MaintenanceType");
					MaintenanceType15.setValue("A");
					Description15.setAttributeNode(MaintenanceType15);
					Attr DescriptionCode15 = doc.createAttribute("DescriptionCode");
					DescriptionCode15.setValue("FAB");
					Description15.setAttributeNode(DescriptionCode15);
					Attr Sequence15 = doc.createAttribute("Sequence");
					Sequence15.setValue("1");
					Description15.setAttributeNode(Sequence15);
					Attr LanguageCode15 = doc.createAttribute("LanguageCode");
					LanguageCode15.setValue("EN");
					Description15.setAttributeNode(LanguageCode15);

					Description15.appendChild(doc.createTextNode("Feature 1 - Good Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description15);

					Element Description16 = doc.createElement("Description");
					Attr MaintenanceType16 = doc.createAttribute("MaintenanceType");
					MaintenanceType16.setValue("A");
					Description16.setAttributeNode(MaintenanceType16);
					Attr DescriptionCode16 = doc.createAttribute("DescriptionCode");
					DescriptionCode16.setValue("FAB");
					Description16.setAttributeNode(DescriptionCode16);
					Attr Sequence16 = doc.createAttribute("Sequence");
					Sequence16.setValue("2");
					Description16.setAttributeNode(Sequence16);
					Attr LanguageCode16 = doc.createAttribute("LanguageCode");
					LanguageCode16.setValue("EN");
					Description16.setAttributeNode(LanguageCode16);

					Description16.appendChild(doc.createTextNode("Feature 2 - Better Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description16);

					Element Description17 = doc.createElement("Description");
					Attr MaintenanceType17 = doc.createAttribute("MaintenanceType");
					MaintenanceType17.setValue("A");
					Description17.setAttributeNode(MaintenanceType17);
					Attr DescriptionCode17 = doc.createAttribute("DescriptionCode");
					DescriptionCode17.setValue("FAB");
					Description17.setAttributeNode(DescriptionCode17);
					Attr Sequence17 = doc.createAttribute("Sequence");
					Sequence17.setValue("3");
					Description17.setAttributeNode(Sequence17);
					Attr LanguageCode17 = doc.createAttribute("LanguageCode");
					LanguageCode17.setValue("EN");
					Description17.setAttributeNode(LanguageCode17);

					Description17.appendChild(doc.createTextNode("Feature 3 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description17);

					Element Description18 = doc.createElement("Description");
					Attr MaintenanceType18 = doc.createAttribute("MaintenanceType");
					MaintenanceType18.setValue("A");
					Description18.setAttributeNode(MaintenanceType18);
					Attr DescriptionCode18 = doc.createAttribute("DescriptionCode");
					DescriptionCode18.setValue("FAB");
					Description18.setAttributeNode(DescriptionCode18);
					Attr Sequence18 = doc.createAttribute("Sequence");
					Sequence18.setValue("4");
					Description18.setAttributeNode(Sequence18);
					Attr LanguageCode18 = doc.createAttribute("LanguageCode");
					LanguageCode18.setValue("EN");
					Description18.setAttributeNode(LanguageCode18);

					Description18.appendChild(doc.createTextNode("Feature 4 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description18);

					Element Description19 = doc.createElement("Description");
					Attr MaintenanceType19 = doc.createAttribute("MaintenanceType");
					MaintenanceType19.setValue("A");
					Description19.setAttributeNode(MaintenanceType19);
					Attr DescriptionCode19 = doc.createAttribute("DescriptionCode");
					DescriptionCode19.setValue("FAB");
					Description19.setAttributeNode(DescriptionCode19);
					Attr Sequence19 = doc.createAttribute("Sequence");
					Sequence19.setValue("5");
					Description19.setAttributeNode(Sequence19);
					Attr LanguageCode19 = doc.createAttribute("LanguageCode");
					LanguageCode19.setValue("EN");
					Description19.setAttributeNode(LanguageCode19);

					Description19.appendChild(doc.createTextNode("Feature 5 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description19);

					Element Description20 = doc.createElement("Description");
					Attr MaintenanceType20 = doc.createAttribute("MaintenanceType");
					MaintenanceType20.setValue("A");
					Description20.setAttributeNode(MaintenanceType20);
					Attr DescriptionCode20 = doc.createAttribute("DescriptionCode");
					DescriptionCode20.setValue("FAB");
					Description20.setAttributeNode(DescriptionCode20);
					Attr Sequence20 = doc.createAttribute("Sequence");
					Sequence20.setValue("6");
					Description20.setAttributeNode(Sequence20);
					Attr LanguageCode20 = doc.createAttribute("LanguageCode");
					LanguageCode20.setValue("EN");
					Description20.setAttributeNode(LanguageCode20);

					Description20.appendChild(doc.createTextNode("Feature 6 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description20);

					Element Description21 = doc.createElement("Description");
					Attr MaintenanceType21 = doc.createAttribute("MaintenanceType");
					MaintenanceType21.setValue("A");
					Description21.setAttributeNode(MaintenanceType21);
					Attr DescriptionCode21 = doc.createAttribute("DescriptionCode");
					DescriptionCode21.setValue("FAB");
					Description21.setAttributeNode(DescriptionCode21);
					Attr Sequence21 = doc.createAttribute("Sequence");
					Sequence21.setValue("7");
					Description21.setAttributeNode(Sequence21);
					Attr LanguageCode21 = doc.createAttribute("LanguageCode");
					LanguageCode21.setValue("EN");
					Description21.setAttributeNode(LanguageCode21);

					Description21.appendChild(doc.createTextNode("Feature 7 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description21);

					Element Description22 = doc.createElement("Description");
					Attr MaintenanceType22 = doc.createAttribute("MaintenanceType");
					MaintenanceType22.setValue("A");
					Description22.setAttributeNode(MaintenanceType22);
					Attr DescriptionCode22 = doc.createAttribute("DescriptionCode");
					DescriptionCode22.setValue("FAB");
					Description22.setAttributeNode(DescriptionCode22);
					Attr Sequence22 = doc.createAttribute("Sequence");
					Sequence22.setValue("8");
					Description22.setAttributeNode(Sequence22);
					Attr LanguageCode22 = doc.createAttribute("LanguageCode");
					LanguageCode22.setValue("EN");
					Description22.setAttributeNode(LanguageCode22);

					Description22.appendChild(doc.createTextNode("Feature 8 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description22);

					Element Description23 = doc.createElement("Description");
					Attr MaintenanceType23 = doc.createAttribute("MaintenanceType");
					MaintenanceType23.setValue("A");
					Description23.setAttributeNode(MaintenanceType23);
					Attr DescriptionCode23 = doc.createAttribute("DescriptionCode");
					DescriptionCode23.setValue("FAB");
					Description23.setAttributeNode(DescriptionCode23);
					Attr Sequence23 = doc.createAttribute("Sequence");
					Sequence23.setValue("9");
					Description23.setAttributeNode(Sequence23);
					Attr LanguageCode23 = doc.createAttribute("LanguageCode");
					LanguageCode23.setValue("EN");
					Description23.setAttributeNode(LanguageCode23);

					Description23.appendChild(doc.createTextNode("Feature 9 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description23);

					Element Description24 = doc.createElement("Description");
					Attr MaintenanceType24 = doc.createAttribute("MaintenanceType");
					MaintenanceType24.setValue("A");
					Description24.setAttributeNode(MaintenanceType24);
					Attr DescriptionCode24 = doc.createAttribute("DescriptionCode");
					DescriptionCode24.setValue("FAB");
					Description24.setAttributeNode(DescriptionCode24);
					Attr Sequence24 = doc.createAttribute("Sequence");
					Sequence24.setValue("10");
					Description24.setAttributeNode(Sequence24);
					Attr LanguageCode24 = doc.createAttribute("LanguageCode");
					LanguageCode24.setValue("EN");
					Description24.setAttributeNode(LanguageCode24);

					Description24.appendChild(doc.createTextNode("Feature 10 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description24);

					Element Description25 = doc.createElement("Description");
					Attr MaintenanceType25 = doc.createAttribute("MaintenanceType");
					MaintenanceType25.setValue("A");
					Description25.setAttributeNode(MaintenanceType25);
					Attr DescriptionCode25 = doc.createAttribute("DescriptionCode");
					DescriptionCode25.setValue("FAB");
					Description25.setAttributeNode(DescriptionCode25);
					Attr Sequence25 = doc.createAttribute("Sequence");
					Sequence25.setValue("11");
					Description25.setAttributeNode(Sequence25);
					Attr LanguageCode25 = doc.createAttribute("LanguageCode");
					LanguageCode25.setValue("EN");
					Description25.setAttributeNode(LanguageCode25);

					Description25.appendChild(doc.createTextNode("Feature 11 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description25);

					Element Description26 = doc.createElement("Description");
					Attr MaintenanceType26 = doc.createAttribute("MaintenanceType");
					MaintenanceType26.setValue("A");
					Description26.setAttributeNode(MaintenanceType26);
					Attr DescriptionCode26 = doc.createAttribute("DescriptionCode");
					DescriptionCode26.setValue("FAB");
					Description26.setAttributeNode(DescriptionCode26);
					Attr Sequence26 = doc.createAttribute("Sequence");
					Sequence26.setValue("12");
					Description26.setAttributeNode(Sequence26);
					Attr LanguageCode26 = doc.createAttribute("LanguageCode");
					LanguageCode26.setValue("EN");
					Description26.setAttributeNode(LanguageCode26);

					Description26.appendChild(doc.createTextNode("Feature 12 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description26);

					Element Description27 = doc.createElement("Description");
					Attr MaintenanceType27 = doc.createAttribute("MaintenanceType");
					MaintenanceType27.setValue("A");
					Description27.setAttributeNode(MaintenanceType27);
					Attr DescriptionCode27 = doc.createAttribute("DescriptionCode");
					DescriptionCode27.setValue("FAB");
					Description27.setAttributeNode(DescriptionCode27);
					Attr Sequence27 = doc.createAttribute("Sequence");
					Sequence27.setValue("13");
					Description27.setAttributeNode(Sequence27);
					Attr LanguageCode27 = doc.createAttribute("LanguageCode");
					LanguageCode27.setValue("EN");
					Description27.setAttributeNode(LanguageCode27);

					Description27.appendChild(doc.createTextNode("Feature 13 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description27);

					Element Description28 = doc.createElement("Description");
					Attr MaintenanceType28 = doc.createAttribute("MaintenanceType");
					MaintenanceType28.setValue("A");
					Description28.setAttributeNode(MaintenanceType28);
					Attr DescriptionCode28 = doc.createAttribute("DescriptionCode");
					DescriptionCode28.setValue("FAB");
					Description28.setAttributeNode(DescriptionCode28);
					Attr Sequence28 = doc.createAttribute("Sequence");
					Sequence28.setValue("14");
					Description28.setAttributeNode(Sequence28);
					Attr LanguageCode28 = doc.createAttribute("LanguageCode");
					LanguageCode28.setValue("EN");
					Description28.setAttributeNode(LanguageCode28);

					Description28.appendChild(doc.createTextNode("Feature 14 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description28);

					Element Description29 = doc.createElement("Description");
					Attr MaintenanceType29 = doc.createAttribute("MaintenanceType");
					MaintenanceType29.setValue("A");
					Description29.setAttributeNode(MaintenanceType29);
					Attr DescriptionCode29 = doc.createAttribute("DescriptionCode");
					DescriptionCode29.setValue("FAB");
					Description29.setAttributeNode(DescriptionCode29);
					Attr Sequence29 = doc.createAttribute("Sequence");
					Sequence29.setValue("15");
					Description29.setAttributeNode(Sequence29);
					Attr LanguageCode29 = doc.createAttribute("LanguageCode");
					LanguageCode29.setValue("EN");
					Description29.setAttributeNode(LanguageCode29);

					Description29.appendChild(doc.createTextNode("Feature 15 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description29);

					Element Description30 = doc.createElement("Description");
					Attr MaintenanceType30 = doc.createAttribute("MaintenanceType");
					MaintenanceType30.setValue("A");
					Description30.setAttributeNode(MaintenanceType30);
					Attr DescriptionCode30 = doc.createAttribute("DescriptionCode");
					DescriptionCode30.setValue("FAB");
					Description30.setAttributeNode(DescriptionCode30);
					Attr Sequence30 = doc.createAttribute("Sequence");
					Sequence30.setValue("16");
					Description30.setAttributeNode(Sequence30);
					Attr LanguageCode30 = doc.createAttribute("LanguageCode");
					LanguageCode30.setValue("EN");
					Description30.setAttributeNode(LanguageCode30);

					Description30.appendChild(doc.createTextNode("Feature 16 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description30);

					Element Description31 = doc.createElement("Description");
					Attr MaintenanceType31 = doc.createAttribute("MaintenanceType");
					MaintenanceType31.setValue("A");
					Description31.setAttributeNode(MaintenanceType31);
					Attr DescriptionCode31 = doc.createAttribute("DescriptionCode");
					DescriptionCode31.setValue("FAB");
					Description31.setAttributeNode(DescriptionCode31);
					Attr Sequence31 = doc.createAttribute("Sequence");
					Sequence31.setValue("17");
					Description31.setAttributeNode(Sequence31);
					Attr LanguageCode31 = doc.createAttribute("LanguageCode");
					LanguageCode31.setValue("EN");
					Description31.setAttributeNode(LanguageCode31);

					Description31.appendChild(doc.createTextNode("Feature 17 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description31);

					Element Description32 = doc.createElement("Description");
					Attr MaintenanceType32 = doc.createAttribute("MaintenanceType");
					MaintenanceType32.setValue("A");
					Description32.setAttributeNode(MaintenanceType32);
					Attr DescriptionCode32 = doc.createAttribute("DescriptionCode");
					DescriptionCode32.setValue("FAB");
					Description32.setAttributeNode(DescriptionCode32);
					Attr Sequence32 = doc.createAttribute("Sequence");
					Sequence32.setValue("18");
					Description32.setAttributeNode(Sequence32);
					Attr LanguageCode32 = doc.createAttribute("LanguageCode");
					LanguageCode32.setValue("EN");
					Description32.setAttributeNode(LanguageCode32);

					Description32.appendChild(doc.createTextNode("Feature 18 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description32);

					Element Description33 = doc.createElement("Description");
					Attr MaintenanceType33 = doc.createAttribute("MaintenanceType");
					MaintenanceType33.setValue("A");
					Description33.setAttributeNode(MaintenanceType33);
					Attr DescriptionCode33 = doc.createAttribute("DescriptionCode");
					DescriptionCode33.setValue("FAB");
					Description33.setAttributeNode(DescriptionCode33);
					Attr Sequence33 = doc.createAttribute("Sequence");
					Sequence33.setValue("19");
					Description33.setAttributeNode(Sequence33);
					Attr LanguageCode33 = doc.createAttribute("LanguageCode");
					LanguageCode33.setValue("EN");
					Description33.setAttributeNode(LanguageCode33);

					Description33.appendChild(doc.createTextNode("Feature 19 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description33);

					Element Description34 = doc.createElement("Description");
					Attr MaintenanceType34 = doc.createAttribute("MaintenanceType");
					MaintenanceType34.setValue("A");
					Description34.setAttributeNode(MaintenanceType34);
					Attr DescriptionCode34 = doc.createAttribute("DescriptionCode");
					DescriptionCode34.setValue("FAB");
					Description34.setAttributeNode(DescriptionCode34);
					Attr Sequence34 = doc.createAttribute("Sequence");
					Sequence34.setValue("20");
					Description34.setAttributeNode(Sequence34);
					Attr LanguageCode34 = doc.createAttribute("LanguageCode");
					LanguageCode34.setValue("EN");
					Description34.setAttributeNode(LanguageCode34);

					Description34.appendChild(doc.createTextNode("Feature 20 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description34);

					Element Description35 = doc.createElement("Description");
					Attr MaintenanceType35 = doc.createAttribute("MaintenanceType");
					MaintenanceType35.setValue("A");
					Description35.setAttributeNode(MaintenanceType35);
					Attr DescriptionCode35 = doc.createAttribute("DescriptionCode");
					DescriptionCode35.setValue("FAB");
					Description35.setAttributeNode(DescriptionCode35);
					Attr Sequence35 = doc.createAttribute("Sequence");
					Sequence35.setValue("21");
					Description35.setAttributeNode(Sequence35);
					Attr LanguageCode35 = doc.createAttribute("LanguageCode");
					LanguageCode35.setValue("EN");
					Description35.setAttributeNode(LanguageCode35);

					Description35.appendChild(doc.createTextNode("Feature 21 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description35);

					Element Description36 = doc.createElement("Description");
					Attr MaintenanceType36 = doc.createAttribute("MaintenanceType");
					MaintenanceType36.setValue("A");
					Description36.setAttributeNode(MaintenanceType36);
					Attr DescriptionCode36 = doc.createAttribute("DescriptionCode");
					DescriptionCode36.setValue("FAB");
					Description36.setAttributeNode(DescriptionCode36);
					Attr Sequence36 = doc.createAttribute("Sequence");
					Sequence36.setValue("22");
					Description36.setAttributeNode(Sequence36);
					Attr LanguageCode36 = doc.createAttribute("LanguageCode");
					LanguageCode36.setValue("EN");
					Description36.setAttributeNode(LanguageCode36);

					Description36.appendChild(doc.createTextNode("Feature 22 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description36);

					Element Description37 = doc.createElement("Description");
					Attr MaintenanceType37 = doc.createAttribute("MaintenanceType");
					MaintenanceType37.setValue("A");
					Description37.setAttributeNode(MaintenanceType37);
					Attr DescriptionCode37 = doc.createAttribute("DescriptionCode");
					DescriptionCode37.setValue("FAB");
					Description37.setAttributeNode(DescriptionCode37);
					Attr Sequence37 = doc.createAttribute("Sequence");
					Sequence37.setValue("23");
					Description37.setAttributeNode(Sequence37);
					Attr LanguageCode37 = doc.createAttribute("LanguageCode");
					LanguageCode37.setValue("EN");
					Description37.setAttributeNode(LanguageCode37);

					Description37.appendChild(doc.createTextNode("Feature 23 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description37);

					Element Description38 = doc.createElement("Description");
					Attr MaintenanceType38 = doc.createAttribute("MaintenanceType");
					MaintenanceType38.setValue("A");
					Description38.setAttributeNode(MaintenanceType38);
					Attr DescriptionCode38 = doc.createAttribute("DescriptionCode");
					DescriptionCode38.setValue("FAB");
					Description38.setAttributeNode(DescriptionCode38);
					Attr Sequence38 = doc.createAttribute("Sequence");
					Sequence38.setValue("24");
					Description38.setAttributeNode(Sequence38);
					Attr LanguageCode38 = doc.createAttribute("LanguageCode");
					LanguageCode38.setValue("EN");
					Description38.setAttributeNode(LanguageCode38);

					Description38.appendChild(doc.createTextNode("Feature 24 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description38);

					Element Description39 = doc.createElement("Description");
					Attr MaintenanceType39 = doc.createAttribute("MaintenanceType");
					MaintenanceType39.setValue("A");
					Description39.setAttributeNode(MaintenanceType39);
					Attr DescriptionCode39 = doc.createAttribute("DescriptionCode");
					DescriptionCode39.setValue("FAB");
					Description39.setAttributeNode(DescriptionCode39);
					Attr Sequence39 = doc.createAttribute("Sequence");
					Sequence39.setValue("25");
					Description39.setAttributeNode(Sequence39);
					Attr LanguageCode39 = doc.createAttribute("LanguageCode");
					LanguageCode39.setValue("EN");
					Description39.setAttributeNode(LanguageCode39);

					Description39.appendChild(doc.createTextNode("Feature 25 - Best Stock Replacement Oil Pump"));
					Descriptions.appendChild(Description39);

					Element Prices = doc.createElement("Prices");
					Item.appendChild(Prices);

					if (coreBaseCost.equalsIgnoreCase("N")) {
						// Pricing1
						Element Pricing = doc.createElement("Pricing");
						Attr MaintenanceTypePrice = doc.createAttribute("MaintenanceType");
						MaintenanceTypePrice.setValue("A");
						Pricing.setAttributeNode(MaintenanceTypePrice);
						Attr PriceType = doc.createAttribute("PriceType");
						PriceType.setValue("RET");
						Pricing.setAttributeNode(PriceType);
						Prices.appendChild(Pricing);

						Element PriceSheetNumber = doc.createElement("PriceSheetNumber");
						PriceSheetNumber.appendChild(doc.createTextNode(PartNo + i + "_A"));
						Pricing.appendChild(PriceSheetNumber);

						Element CurrencyCode = doc.createElement("CurrencyCode");
						CurrencyCode.appendChild(doc.createTextNode("USD"));
						Pricing.appendChild(CurrencyCode);

						Element EffectiveDate = doc.createElement("EffectiveDate");
						EffectiveDate.appendChild(doc.createTextNode("2019-02-01"));
						Pricing.appendChild(EffectiveDate);

						Element Price = doc.createElement("Price");
						Attr UOMPrice = doc.createAttribute("UOM");
						UOMPrice.setValue("PE");
						Price.setAttributeNode(UOMPrice);
						Price.appendChild(doc.createTextNode(String.valueOf(RETPrice)));
						Pricing.appendChild(Price);

						// Pricing2
						Element Pricing2 = doc.createElement("Pricing");
						Attr MaintenanceTypePrice2 = doc.createAttribute("MaintenanceType");
						MaintenanceTypePrice2.setValue("A");
						Pricing2.setAttributeNode(MaintenanceTypePrice2);
						Attr PriceType2 = doc.createAttribute("PriceType");
						PriceType2.setValue("ZZ1");
						Pricing2.setAttributeNode(PriceType2);
						Prices.appendChild(Pricing2);

						Element PriceSheetNumber2 = doc.createElement("PriceSheetNumber");
						PriceSheetNumber2.appendChild(doc.createTextNode(PartNo + i + "_B"));
						Pricing2.appendChild(PriceSheetNumber2);

						Element CurrencyCode2 = doc.createElement("CurrencyCode");
						CurrencyCode2.appendChild(doc.createTextNode("USD"));
						Pricing2.appendChild(CurrencyCode2);

						Element EffectiveDate2 = doc.createElement("EffectiveDate");
						EffectiveDate2.appendChild(doc.createTextNode("2019-02-01"));
						Pricing2.appendChild(EffectiveDate2);

						Element Price2 = doc.createElement("Price");
						Attr UOMPrice2 = doc.createAttribute("UOM");
						UOMPrice2.setValue("PE");
						Price2.setAttributeNode(UOMPrice2);
						Price2.appendChild(doc.createTextNode(String.valueOf(ZZ1Price)));
						Pricing2.appendChild(Price2);

					} else {
						// Pricing1

						Element Pricing1 = doc.createElement("Pricing");
						Attr MaintenanceTypePrice1 = doc.createAttribute("MaintenanceType");
						MaintenanceTypePrice1.setValue("A");
						Pricing1.setAttributeNode(MaintenanceTypePrice1);
						Attr PriceType1 = doc.createAttribute("PriceType");
						PriceType1.setValue("RET");
						Pricing1.setAttributeNode(PriceType1);
						Prices.appendChild(Pricing1);

						Element PriceSheetNumber1 = doc.createElement("PriceSheetNumber");
						PriceSheetNumber1.appendChild(doc.createTextNode(PartNo + i + "_A"));
						Pricing1.appendChild(PriceSheetNumber1);

						Element CurrencyCode1 = doc.createElement("CurrencyCode");
						CurrencyCode1.appendChild(doc.createTextNode("USD"));
						Pricing1.appendChild(CurrencyCode1);

						Element EffectiveDate1 = doc.createElement("EffectiveDate");
						EffectiveDate1.appendChild(doc.createTextNode("1019-01-01"));
						Pricing1.appendChild(EffectiveDate1);

						Element Price1 = doc.createElement("Price");
						Attr UOMPrice1 = doc.createAttribute("UOM");
						UOMPrice1.setValue("PE");
						Price1.setAttributeNode(UOMPrice1);
						Price1.appendChild(doc.createTextNode(String.valueOf(RETPrice)));
						Pricing1.appendChild(Price1);

						// Pricing2
						Element Pricing2 = doc.createElement("Pricing");
						Attr MaintenanceTypePrice2 = doc.createAttribute("MaintenanceType");
						MaintenanceTypePrice2.setValue("A");
						Pricing2.setAttributeNode(MaintenanceTypePrice2);
						Attr PriceType2 = doc.createAttribute("PriceType");
						PriceType2.setValue("ZZ1");
						Pricing2.setAttributeNode(PriceType2);
						Prices.appendChild(Pricing2);

						Element PriceSheetNumber2 = doc.createElement("PriceSheetNumber");
						PriceSheetNumber2.appendChild(doc.createTextNode(PartNo + i + "_B"));
						Pricing2.appendChild(PriceSheetNumber2);

						Element CurrencyCode2 = doc.createElement("CurrencyCode");
						CurrencyCode2.appendChild(doc.createTextNode("USD"));
						Pricing2.appendChild(CurrencyCode2);

						Element EffectiveDate2 = doc.createElement("EffectiveDate");
						EffectiveDate2.appendChild(doc.createTextNode("2019-02-01"));
						Pricing2.appendChild(EffectiveDate2);

						Element Price2 = doc.createElement("Price");
						Attr UOMPrice2 = doc.createAttribute("UOM");
						UOMPrice2.setValue("PE");
						Price2.setAttributeNode(UOMPrice2);
						Price2.appendChild(doc.createTextNode(String.valueOf(ZZ1Price)));
						Pricing2.appendChild(Price2);

						// Pricing3
						Element Pricing3 = doc.createElement("Pricing");
						Attr MaintenanceTypePrice3 = doc.createAttribute("MaintenanceType");
						MaintenanceTypePrice3.setValue("A");
						Pricing3.setAttributeNode(MaintenanceTypePrice3);
						Attr PriceType3 = doc.createAttribute("PriceType");
						PriceType3.setValue("ZZ2");
						Pricing3.setAttributeNode(PriceType3);
						Prices.appendChild(Pricing3);

						Element PriceSheetNumber3 = doc.createElement("PriceSheetNumber");
						PriceSheetNumber3.appendChild(doc.createTextNode(PartNo + i + "_C"));
						Pricing3.appendChild(PriceSheetNumber3);

						Element CurrencyCode3 = doc.createElement("CurrencyCode");
						CurrencyCode3.appendChild(doc.createTextNode("USD"));
						Pricing3.appendChild(CurrencyCode3);

						Element EffectiveDate3 = doc.createElement("EffectiveDate");
						EffectiveDate3.appendChild(doc.createTextNode("2019-02-01"));
						Pricing3.appendChild(EffectiveDate3);

						Element Price3 = doc.createElement("Price");
						Attr UOMPrice3 = doc.createAttribute("UOM");
						UOMPrice3.setValue("PE");
						Price3.setAttributeNode(UOMPrice3);
						Price3.appendChild(doc.createTextNode(String.valueOf(ZZ2Price)));
						Pricing3.appendChild(Price3);

						// Pricing4
						Element Pricing4 = doc.createElement("Pricing");
						Attr MaintenanceTypePrice4 = doc.createAttribute("MaintenanceType");
						MaintenanceTypePrice4.setValue("A");
						Pricing4.setAttributeNode(MaintenanceTypePrice4);
						Attr PriceType4 = doc.createAttribute("PriceType");
						PriceType4.setValue("CRG");
						Pricing4.setAttributeNode(PriceType4);
						Prices.appendChild(Pricing4);

						Element PriceSheetNumber4 = doc.createElement("PriceSheetNumber");
						PriceSheetNumber4.appendChild(doc.createTextNode(PartNo + i + "_D"));
						Pricing4.appendChild(PriceSheetNumber4);

						Element CurrencyCode4 = doc.createElement("CurrencyCode");
						CurrencyCode4.appendChild(doc.createTextNode("USD"));
						Pricing4.appendChild(CurrencyCode4);

						Element EffectiveDate4 = doc.createElement("EffectiveDate");
						EffectiveDate4.appendChild(doc.createTextNode("4019-04-01"));
						Pricing4.appendChild(EffectiveDate4);

						Element Price4 = doc.createElement("Price");
						Attr UOMPrice4 = doc.createAttribute("UOM");
						UOMPrice4.setValue("PE");
						Price4.setAttributeNode(UOMPrice4);
						Price4.appendChild(doc.createTextNode(String.valueOf(CRGPrice)));
						Pricing4.appendChild(Price4);

					}

					// Extended Information
					Element ExtendedInformation = doc.createElement("ExtendedInformation");
					Item.appendChild(ExtendedInformation);

					Element ExtendedProductInformation = doc.createElement("ExtendedProductInformation");
					Attr MaintenanceTypeExtended = doc.createAttribute("MaintenanceType");
					MaintenanceTypeExtended.setValue("A");
					ExtendedProductInformation.setAttributeNode(MaintenanceTypeExtended);
					Attr EXPICode = doc.createAttribute("EXPICode");
					EXPICode.setValue("CTO");
					ExtendedProductInformation.setAttributeNode(EXPICode);
					Attr LanguageCodeExtended = doc.createAttribute("LanguageCode");
					LanguageCodeExtended.setValue("EN");
					ExtendedProductInformation.setAttributeNode(LanguageCodeExtended);

					ExtendedProductInformation.appendChild(doc.createTextNode("CN"));
					ExtendedInformation.appendChild(ExtendedProductInformation);

					Element ExtendedProductInformation2 = doc.createElement("ExtendedProductInformation");
					Attr MaintenanceTypeExtended2 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeExtended2.setValue("A");
					ExtendedProductInformation2.setAttributeNode(MaintenanceTypeExtended2);
					Attr EXPICode2 = doc.createAttribute("EXPICode");
					EXPICode2.setValue("EMS");
					ExtendedProductInformation2.setAttributeNode(EXPICode2);
					Attr LanguageCodeExtended2 = doc.createAttribute("LanguageCode");
					LanguageCodeExtended2.setValue("EN");
					ExtendedProductInformation2.setAttributeNode(LanguageCodeExtended2);

					ExtendedProductInformation2.appendChild(doc.createTextNode("1"));
					ExtendedInformation.appendChild(ExtendedProductInformation2);

					Element ExtendedProductInformation3 = doc.createElement("ExtendedProductInformation");
					Attr MaintenanceTypeExtended3 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeExtended3.setValue("A");
					ExtendedProductInformation3.setAttributeNode(MaintenanceTypeExtended3);
					Attr EXPICode3 = doc.createAttribute("EXPICode");
					EXPICode3.setValue("HTS");
					ExtendedProductInformation3.setAttributeNode(EXPICode3);
					Attr LanguageCodeExtended3 = doc.createAttribute("LanguageCode");
					LanguageCodeExtended3.setValue("EN");
					ExtendedProductInformation3.setAttributeNode(LanguageCodeExtended3);

					ExtendedProductInformation3.appendChild(doc.createTextNode("4012124025"));
					ExtendedInformation.appendChild(ExtendedProductInformation3);

					Element ExtendedProductInformation4 = doc.createElement("ExtendedProductInformation");
					Attr MaintenanceTypeExtended4 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeExtended4.setValue("A");
					ExtendedProductInformation4.setAttributeNode(MaintenanceTypeExtended4);
					Attr EXPICode4 = doc.createAttribute("EXPICode");
					EXPICode4.setValue("LIS");
					ExtendedProductInformation4.setAttributeNode(EXPICode4);
					Attr LanguageCodeExtended4 = doc.createAttribute("LanguageCode");
					LanguageCodeExtended4.setValue("EN");
					ExtendedProductInformation4.setAttributeNode(LanguageCodeExtended4);

					ExtendedProductInformation4.appendChild(doc.createTextNode("Available to Order"));
					ExtendedInformation.appendChild(ExtendedProductInformation4);

					Element ExtendedProductInformation5 = doc.createElement("ExtendedProductInformation");
					Attr MaintenanceTypeExtended5 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeExtended5.setValue("A");
					ExtendedProductInformation5.setAttributeNode(MaintenanceTypeExtended5);
					Attr EXPICode5 = doc.createAttribute("EXPICode");
					EXPICode5.setValue("NPC");
					ExtendedProductInformation5.setAttributeNode(EXPICode5);
					Attr LanguageCodeExtended5 = doc.createAttribute("LanguageCode");
					LanguageCodeExtended5.setValue("EN");
					ExtendedProductInformation5.setAttributeNode(LanguageCodeExtended5);

					ExtendedProductInformation5.appendChild(doc.createTextNode("W"));
					ExtendedInformation.appendChild(ExtendedProductInformation5);

					Element ExtendedProductInformation6 = doc.createElement("ExtendedProductInformation");
					Attr MaintenanceTypeExtended6 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeExtended6.setValue("A");
					ExtendedProductInformation6.setAttributeNode(MaintenanceTypeExtended6);
					Attr EXPICode6 = doc.createAttribute("EXPICode");
					EXPICode6.setValue("NPD");
					ExtendedProductInformation6.setAttributeNode(EXPICode6);
					Attr LanguageCodeExtended6 = doc.createAttribute("LanguageCode");
					LanguageCodeExtended6.setValue("EN");
					ExtendedProductInformation6.setAttributeNode(LanguageCodeExtended6);

					ExtendedProductInformation6.appendChild(doc.createTextNode("Non-Stock Item"));
					ExtendedInformation.appendChild(ExtendedProductInformation6);

					Element ExtendedProductInformation7 = doc.createElement("ExtendedProductInformation");
					Attr MaintenanceTypeExtended7 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeExtended7.setValue("A");
					ExtendedProductInformation7.setAttributeNode(MaintenanceTypeExtended7);
					Attr EXPICode7 = doc.createAttribute("EXPICode");
					EXPICode7.setValue("PLC");
					ExtendedProductInformation7.setAttributeNode(EXPICode7);
					Attr LanguageCodeExtended7 = doc.createAttribute("LanguageCode");
					LanguageCodeExtended7.setValue("EN");
					ExtendedProductInformation7.setAttributeNode(LanguageCodeExtended7);

					ExtendedProductInformation7.appendChild(doc.createTextNode("1"));
					ExtendedInformation.appendChild(ExtendedProductInformation7);

					Element ExtendedProductInformation8 = doc.createElement("ExtendedProductInformation");
					Attr MaintenanceTypeExtended8 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeExtended8.setValue("A");
					ExtendedProductInformation8.setAttributeNode(MaintenanceTypeExtended8);
					Attr EXPICode8 = doc.createAttribute("EXPICode");
					EXPICode8.setValue("PLM");
					ExtendedProductInformation8.setAttributeNode(EXPICode8);
					Attr LanguageCodeExtended8 = doc.createAttribute("LanguageCode");
					LanguageCodeExtended8.setValue("EN");
					ExtendedProductInformation8.setAttributeNode(LanguageCodeExtended8);

					ExtendedProductInformation8.appendChild(doc.createTextNode("1"));
					ExtendedInformation.appendChild(ExtendedProductInformation8);

					Element ExtendedProductInformation9 = doc.createElement("ExtendedProductInformation");
					Attr MaintenanceTypeExtended9 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeExtended9.setValue("A");
					ExtendedProductInformation9.setAttributeNode(MaintenanceTypeExtended9);
					Attr EXPICode9 = doc.createAttribute("EXPICode");
					EXPICode9.setValue("REM");
					ExtendedProductInformation9.setAttributeNode(EXPICode9);
					Attr LanguageCodeExtended9 = doc.createAttribute("LanguageCode");
					LanguageCodeExtended9.setValue("EN");
					ExtendedProductInformation9.setAttributeNode(LanguageCodeExtended9);

					ExtendedProductInformation9.appendChild(doc.createTextNode("N"));
					ExtendedInformation.appendChild(ExtendedProductInformation9);

					// ProductAttributes
					Element ProductAttributes = doc.createElement("ProductAttributes");
					Item.appendChild(ProductAttributes);

					Element ProductAttribute = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute.setValue("A");
					ProductAttribute.setAttributeNode(MaintenanceTypeProductAttribute);
					Attr AttributeID = doc.createAttribute("AttributeID");
					AttributeID.setValue("AAP_UDA_4");
					ProductAttribute.setAttributeNode(AttributeID);
					Attr PADBAttribute = doc.createAttribute("PADBAttribute");
					PADBAttribute.setValue("N");
					ProductAttribute.setAttributeNode(PADBAttribute);
					Attr LanguageCodeProductAttribute = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute.setValue("EN");
					ProductAttribute.setAttributeNode(LanguageCodeProductAttribute);

					ProductAttribute.appendChild(doc.createTextNode("85"));
					ProductAttributes.appendChild(ProductAttribute);

					Element ProductAttribute2 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute2 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute2.setValue("A");
					ProductAttribute2.setAttributeNode(MaintenanceTypeProductAttribute2);
					Attr AttributeID2 = doc.createAttribute("AttributeID");
					AttributeID2.setValue("AAP_UDA_12");
					ProductAttribute2.setAttributeNode(AttributeID2);
					Attr PADBAttribute2 = doc.createAttribute("PADBAttribute");
					PADBAttribute2.setValue("N");
					ProductAttribute2.setAttributeNode(PADBAttribute2);
					Attr LanguageCodeProductAttribute2 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute2.setValue("EN");
					ProductAttribute2.setAttributeNode(LanguageCodeProductAttribute2);

					ProductAttribute2.appendChild(doc.createTextNode("EA"));
					ProductAttributes.appendChild(ProductAttribute2);

					Element ProductAttribute3 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute3 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute3.setValue("A");
					ProductAttribute3.setAttributeNode(MaintenanceTypeProductAttribute3);
					Attr AttributeID3 = doc.createAttribute("AttributeID");
					AttributeID3.setValue("AAP_UDA_22");
					ProductAttribute3.setAttributeNode(AttributeID3);
					Attr PADBAttribute3 = doc.createAttribute("PADBAttribute");
					PADBAttribute3.setValue("N");
					ProductAttribute3.setAttributeNode(PADBAttribute3);
					Attr LanguageCodeProductAttribute3 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute3.setValue("EN");
					ProductAttribute3.setAttributeNode(LanguageCodeProductAttribute3);

					ProductAttribute3.appendChild(doc.createTextNode("20"));
					ProductAttributes.appendChild(ProductAttribute3);

					Element ProductAttribute4 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute4 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute4.setValue("A");
					ProductAttribute4.setAttributeNode(MaintenanceTypeProductAttribute4);
					Attr AttributeID4 = doc.createAttribute("AttributeID");
					AttributeID4.setValue("AAP_UDA_31");
					ProductAttribute4.setAttributeNode(AttributeID4);
					Attr PADBAttribute4 = doc.createAttribute("PADBAttribute");
					PADBAttribute4.setValue("N");
					ProductAttribute4.setAttributeNode(PADBAttribute4);
					Attr LanguageCodeProductAttribute4 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute4.setValue("EN");
					ProductAttribute4.setAttributeNode(LanguageCodeProductAttribute4);

					ProductAttribute4.appendChild(doc.createTextNode("151"));
					ProductAttributes.appendChild(ProductAttribute4);

					Element ProductAttribute5 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute5 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute5.setValue("A");
					ProductAttribute5.setAttributeNode(MaintenanceTypeProductAttribute5);
					Attr AttributeID5 = doc.createAttribute("AttributeID");
					AttributeID5.setValue("AAP_UDA_32");
					ProductAttribute5.setAttributeNode(AttributeID5);
					Attr PADBAttribute5 = doc.createAttribute("PADBAttribute");
					PADBAttribute5.setValue("N");
					ProductAttribute5.setAttributeNode(PADBAttribute5);
					Attr LanguageCodeProductAttribute5 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute5.setValue("EN");
					ProductAttribute5.setAttributeNode(LanguageCodeProductAttribute5);

					ProductAttribute5.appendChild(doc.createTextNode("MEL"));
					ProductAttributes.appendChild(ProductAttribute5);

					Element ProductAttribute6 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute6 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute6.setValue("A");
					ProductAttribute6.setAttributeNode(MaintenanceTypeProductAttribute6);
					Attr AttributeID6 = doc.createAttribute("AttributeID");
					AttributeID6.setValue("AAP_UDA_120");
					ProductAttribute6.setAttributeNode(AttributeID6);
					Attr PADBAttribute6 = doc.createAttribute("PADBAttribute");
					PADBAttribute6.setValue("N");
					ProductAttribute6.setAttributeNode(PADBAttribute6);
					Attr LanguageCodeProductAttribute6 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute6.setValue("EN");
					ProductAttribute6.setAttributeNode(LanguageCodeProductAttribute6);

					ProductAttribute6.appendChild(doc.createTextNode("Y"));
					ProductAttributes.appendChild(ProductAttribute6);

					Element ProductAttribute7 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute7 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute7.setValue("A");
					ProductAttribute7.setAttributeNode(MaintenanceTypeProductAttribute7);
					Attr AttributeID7 = doc.createAttribute("AttributeID");
					AttributeID7.setValue("AAP_UDA_121");
					ProductAttribute7.setAttributeNode(AttributeID7);
					Attr PADBAttribute7 = doc.createAttribute("PADBAttribute");
					PADBAttribute7.setValue("N");
					ProductAttribute7.setAttributeNode(PADBAttribute7);
					Attr LanguageCodeProductAttribute7 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute7.setValue("EN");
					ProductAttribute7.setAttributeNode(LanguageCodeProductAttribute7);

					ProductAttribute7.appendChild(doc.createTextNode("N"));
					ProductAttributes.appendChild(ProductAttribute7);

					Element ProductAttribute8 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute8 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute8.setValue("A");
					ProductAttribute8.setAttributeNode(MaintenanceTypeProductAttribute8);
					Attr AttributeID8 = doc.createAttribute("AttributeID");
					AttributeID8.setValue("AAP_UDA_122");
					ProductAttribute8.setAttributeNode(AttributeID8);
					Attr PADBAttribute8 = doc.createAttribute("PADBAttribute");
					PADBAttribute8.setValue("N");
					ProductAttribute8.setAttributeNode(PADBAttribute8);
					Attr LanguageCodeProductAttribute8 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute8.setValue("EN");
					ProductAttribute8.setAttributeNode(LanguageCodeProductAttribute8);

					ProductAttribute8.appendChild(doc.createTextNode("N"));
					ProductAttributes.appendChild(ProductAttribute8);

					Element ProductAttribute9 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute9 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute9.setValue("A");
					ProductAttribute9.setAttributeNode(MaintenanceTypeProductAttribute9);
					Attr AttributeID9 = doc.createAttribute("AttributeID");
					AttributeID9.setValue("AAP_UDA_123");
					ProductAttribute9.setAttributeNode(AttributeID9);
					Attr PADBAttribute9 = doc.createAttribute("PADBAttribute");
					PADBAttribute9.setValue("N");
					ProductAttribute9.setAttributeNode(PADBAttribute9);
					Attr LanguageCodeProductAttribute9 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute9.setValue("EN");
					ProductAttribute9.setAttributeNode(LanguageCodeProductAttribute9);

					ProductAttribute9.appendChild(doc.createTextNode("N"));
					ProductAttributes.appendChild(ProductAttribute9);

					Element ProductAttribute10 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute10 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute10.setValue("A");
					ProductAttribute10.setAttributeNode(MaintenanceTypeProductAttribute10);
					Attr AttributeID10 = doc.createAttribute("AttributeID");
					AttributeID10.setValue("AAP_UDA_124");
					ProductAttribute10.setAttributeNode(AttributeID10);
					Attr PADBAttribute10 = doc.createAttribute("PADBAttribute");
					PADBAttribute10.setValue("N");
					ProductAttribute10.setAttributeNode(PADBAttribute10);
					Attr LanguageCodeProductAttribute10 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute10.setValue("EN");
					ProductAttribute10.setAttributeNode(LanguageCodeProductAttribute10);

					ProductAttribute10.appendChild(doc.createTextNode("N"));
					ProductAttributes.appendChild(ProductAttribute10);

					Element ProductAttribute11 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute11 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute11.setValue("A");
					ProductAttribute11.setAttributeNode(MaintenanceTypeProductAttribute11);
					Attr AttributeID11 = doc.createAttribute("AttributeID");
					AttributeID11.setValue("AAP_UDA_125");
					ProductAttribute11.setAttributeNode(AttributeID11);
					Attr PADBAttribute11 = doc.createAttribute("PADBAttribute");
					PADBAttribute11.setValue("N");
					ProductAttribute11.setAttributeNode(PADBAttribute11);
					Attr LanguageCodeProductAttribute11 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute11.setValue("EN");
					ProductAttribute11.setAttributeNode(LanguageCodeProductAttribute11);

					ProductAttribute11.appendChild(doc.createTextNode("N"));
					ProductAttributes.appendChild(ProductAttribute11);

					Element ProductAttribute12 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute12 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute12.setValue("A");
					ProductAttribute12.setAttributeNode(MaintenanceTypeProductAttribute12);
					Attr AttributeID12 = doc.createAttribute("AttributeID");
					AttributeID12.setValue("AAP_UDA_126");
					ProductAttribute12.setAttributeNode(AttributeID12);
					Attr PADBAttribute12 = doc.createAttribute("PADBAttribute");
					PADBAttribute12.setValue("N");
					ProductAttribute12.setAttributeNode(PADBAttribute12);
					Attr LanguageCodeProductAttribute12 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute12.setValue("EN");
					ProductAttribute12.setAttributeNode(LanguageCodeProductAttribute12);

					ProductAttribute12.appendChild(doc.createTextNode("N"));
					ProductAttributes.appendChild(ProductAttribute12);

					Element ProductAttribute13 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute13 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute13.setValue("A");
					ProductAttribute13.setAttributeNode(MaintenanceTypeProductAttribute13);
					Attr AttributeID13 = doc.createAttribute("AttributeID");
					AttributeID13.setValue("AAP_UDA_127");
					ProductAttribute13.setAttributeNode(AttributeID13);
					Attr PADBAttribute13 = doc.createAttribute("PADBAttribute");
					PADBAttribute13.setValue("N");
					ProductAttribute13.setAttributeNode(PADBAttribute13);
					Attr LanguageCodeProductAttribute13 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute13.setValue("EN");
					ProductAttribute13.setAttributeNode(LanguageCodeProductAttribute13);

					ProductAttribute13.appendChild(doc.createTextNode("N"));
					ProductAttributes.appendChild(ProductAttribute13);

					Element ProductAttribute14 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute14 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute14.setValue("A");
					ProductAttribute14.setAttributeNode(MaintenanceTypeProductAttribute14);
					Attr AttributeID14 = doc.createAttribute("AttributeID");
					AttributeID14.setValue("AAP_UDA_128");
					ProductAttribute14.setAttributeNode(AttributeID14);
					Attr PADBAttribute14 = doc.createAttribute("PADBAttribute");
					PADBAttribute14.setValue("N");
					ProductAttribute14.setAttributeNode(PADBAttribute14);
					Attr LanguageCodeProductAttribute14 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute14.setValue("EN");
					ProductAttribute14.setAttributeNode(LanguageCodeProductAttribute14);

					ProductAttribute14.appendChild(doc.createTextNode("N"));
					ProductAttributes.appendChild(ProductAttribute14);

					Element ProductAttribute15 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute15 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute15.setValue("A");
					ProductAttribute15.setAttributeNode(MaintenanceTypeProductAttribute15);
					Attr AttributeID15 = doc.createAttribute("AttributeID");
					AttributeID15.setValue("AAP_UDA_129");
					ProductAttribute15.setAttributeNode(AttributeID15);
					Attr PADBAttribute15 = doc.createAttribute("PADBAttribute");
					PADBAttribute15.setValue("N");
					ProductAttribute15.setAttributeNode(PADBAttribute15);
					Attr LanguageCodeProductAttribute15 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute15.setValue("EN");
					ProductAttribute15.setAttributeNode(LanguageCodeProductAttribute15);

					ProductAttribute15.appendChild(doc.createTextNode("N"));
					ProductAttributes.appendChild(ProductAttribute15);

					Element ProductAttribute16 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute16 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute16.setValue("A");
					ProductAttribute16.setAttributeNode(MaintenanceTypeProductAttribute16);
					Attr AttributeID16 = doc.createAttribute("AttributeID");
					AttributeID16.setValue("AAP_UDA_130");
					ProductAttribute16.setAttributeNode(AttributeID16);
					Attr PADBAttribute16 = doc.createAttribute("PADBAttribute");
					PADBAttribute16.setValue("N");
					ProductAttribute16.setAttributeNode(PADBAttribute16);
					Attr LanguageCodeProductAttribute16 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute16.setValue("EN");
					ProductAttribute16.setAttributeNode(LanguageCodeProductAttribute16);

					ProductAttribute16.appendChild(doc.createTextNode("N"));
					ProductAttributes.appendChild(ProductAttribute16);

					Element ProductAttribute17 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute17 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute17.setValue("A");
					ProductAttribute17.setAttributeNode(MaintenanceTypeProductAttribute17);
					Attr AttributeID17 = doc.createAttribute("AttributeID");
					AttributeID17.setValue("AAP_UDA_131");
					ProductAttribute17.setAttributeNode(AttributeID17);
					Attr PADBAttribute17 = doc.createAttribute("PADBAttribute");
					PADBAttribute17.setValue("N");
					ProductAttribute17.setAttributeNode(PADBAttribute17);
					Attr LanguageCodeProductAttribute17 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute17.setValue("EN");
					ProductAttribute17.setAttributeNode(LanguageCodeProductAttribute17);

					ProductAttribute17.appendChild(doc.createTextNode("Y"));
					ProductAttributes.appendChild(ProductAttribute17);

					Element ProductAttribute18 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute18 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute18.setValue("A");
					ProductAttribute18.setAttributeNode(MaintenanceTypeProductAttribute18);
					Attr AttributeID18 = doc.createAttribute("AttributeID");
					AttributeID18.setValue("AAP_UDA_132");
					ProductAttribute18.setAttributeNode(AttributeID18);
					Attr PADBAttribute18 = doc.createAttribute("PADBAttribute");
					PADBAttribute18.setValue("N");
					ProductAttribute18.setAttributeNode(PADBAttribute18);
					Attr LanguageCodeProductAttribute18 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute18.setValue("EN");
					ProductAttribute18.setAttributeNode(LanguageCodeProductAttribute18);

					ProductAttribute18.appendChild(doc.createTextNode("N"));
					ProductAttributes.appendChild(ProductAttribute18);

					Element ProductAttribute19 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute19 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute19.setValue("A");
					ProductAttribute19.setAttributeNode(MaintenanceTypeProductAttribute19);
					Attr AttributeID19 = doc.createAttribute("AttributeID");
					AttributeID19.setValue("AAP_UDA_133");
					ProductAttribute19.setAttributeNode(AttributeID19);
					Attr PADBAttribute19 = doc.createAttribute("PADBAttribute");
					PADBAttribute19.setValue("N");
					ProductAttribute19.setAttributeNode(PADBAttribute19);
					Attr LanguageCodeProductAttribute19 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute19.setValue("EN");
					ProductAttribute19.setAttributeNode(LanguageCodeProductAttribute19);

					ProductAttribute19.appendChild(doc.createTextNode("N"));
					ProductAttributes.appendChild(ProductAttribute19);

					Element ProductAttribute20 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute20 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute20.setValue("A");
					ProductAttribute20.setAttributeNode(MaintenanceTypeProductAttribute20);
					Attr AttributeID20 = doc.createAttribute("AttributeID");
					AttributeID20.setValue("AAP_UDA_119");
					ProductAttribute20.setAttributeNode(AttributeID20);
					Attr PADBAttribute20 = doc.createAttribute("PADBAttribute");
					PADBAttribute20.setValue("N");
					ProductAttribute20.setAttributeNode(PADBAttribute20);
					Attr LanguageCodeProductAttribute20 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute20.setValue("EN");
					ProductAttribute20.setAttributeNode(LanguageCodeProductAttribute20);

					ProductAttribute20.appendChild(doc.createTextNode("Y"));
					ProductAttributes.appendChild(ProductAttribute20);

					Element ProductAttribute21 = doc.createElement("ProductAttribute");
					Attr MaintenanceTypeProductAttribute21 = doc.createAttribute("MaintenanceType");
					MaintenanceTypeProductAttribute21.setValue("A");
					ProductAttribute21.setAttributeNode(MaintenanceTypeProductAttribute21);
					Attr AttributeID21 = doc.createAttribute("AttributeID");
					AttributeID21.setValue("AC_PIES_EXPILIF");
					ProductAttribute21.setAttributeNode(AttributeID21);
					Attr PADBAttribute21 = doc.createAttribute("PADBAttribute");
					PADBAttribute21.setValue("N");
					ProductAttribute21.setAttributeNode(PADBAttribute21);
					Attr LanguageCodeProductAttribute21 = doc.createAttribute("LanguageCode");
					LanguageCodeProductAttribute21.setValue("EN");
					ProductAttribute21.setAttributeNode(LanguageCodeProductAttribute21);

					ProductAttribute21.appendChild(doc.createTextNode("2"));
					ProductAttributes.appendChild(ProductAttribute21);

					// Packages
					Element Packages = doc.createElement("Packages");
					Item.appendChild(Packages);
					
					
					// Packages.appendChild(Package);
					if(PackageCount==1){
						Element Package = doc.createElement("Package");
						Attr MaintenanceTypePackage = doc.createAttribute("MaintenanceType");
						MaintenanceTypePackage.setValue("A");
						Package.setAttributeNode(MaintenanceTypePackage);

						Element PackageLevelGTIN = doc.createElement("PackageLevelGTIN");
						PackageLevelGTIN.appendChild(doc.createTextNode("00000000000000"));
						Package.appendChild(PackageLevelGTIN);

						Element PackageBarCodeCharacters = doc.createElement("PackageBarCodeCharacters");
						PackageBarCodeCharacters.appendChild(doc.createTextNode("00000000000000"));
						Package.appendChild(PackageBarCodeCharacters);

						Element PackageUOM = doc.createElement("PackageUOM");
						PackageUOM.appendChild(doc.createTextNode(packtype));
						Package.appendChild(PackageUOM);

						Element QuantityofEaches = doc.createElement("QuantityofEaches");
						QuantityofEaches.appendChild(doc.createTextNode("1"));
						Package.appendChild(QuantityofEaches);

						Element Dimensions = doc.createElement("Dimensions");
						Attr UOMDimensions = doc.createAttribute("UOM");
						UOMDimensions.setValue("IN");
						Dimensions.setAttributeNode(UOMDimensions);
						Package.appendChild(Dimensions);

						Element Height = doc.createElement("Height");
						Height.appendChild(doc.createTextNode("1"));
						Dimensions.appendChild(Height);

						Element Width = doc.createElement("Width");
						Width.appendChild(doc.createTextNode("1"));
						Dimensions.appendChild(Width);

						Element Length = doc.createElement("Length");
						Length.appendChild(doc.createTextNode("1"));
						Dimensions.appendChild(Length);

						Element Weights = doc.createElement("Weights");
						Attr UOMWeight = doc.createAttribute("UOM");
						UOMWeight.setValue("PG");
						Weights.setAttributeNode(UOMWeight);
						Package.appendChild(Weights);

						Element Weight = doc.createElement("Weight");

						Weight.appendChild(doc.createTextNode("1"));

						Weights.appendChild(Weight);
						Packages.appendChild(Package);
						}
					else {
						
						for (int j = 1; j < packlist.size(); j++) {
							
							Element Package = doc.createElement("Package");
							Attr MaintenanceTypePackage = doc.createAttribute("MaintenanceType");
							MaintenanceTypePackage.setValue("A");
							Package.setAttributeNode(MaintenanceTypePackage);

							Element PackageLevelGTIN = doc.createElement("PackageLevelGTIN");
							PackageLevelGTIN.appendChild(doc.createTextNode("00000000000000"));
							Package.appendChild(PackageLevelGTIN);

							Element PackageBarCodeCharacters = doc.createElement("PackageBarCodeCharacters");
							PackageBarCodeCharacters.appendChild(doc.createTextNode("00000000000000"));
							Package.appendChild(PackageBarCodeCharacters);

							Element PackageUOM = doc.createElement("PackageUOM");
							PackageUOM.appendChild(doc.createTextNode((String) packlist.get(j)));
							Package.appendChild(PackageUOM);

							Element QuantityofEaches = doc.createElement("QuantityofEaches");
							QuantityofEaches.appendChild(doc.createTextNode(String.valueOf(j)));
							Package.appendChild(QuantityofEaches);

							Element Dimensions = doc.createElement("Dimensions");
							Attr UOMDimensions = doc.createAttribute("UOM");
							UOMDimensions.setValue("IN");
							Dimensions.setAttributeNode(UOMDimensions);
							Package.appendChild(Dimensions);

							Element Height = doc.createElement("Height");
							Height.appendChild(doc.createTextNode(String.valueOf(j)));
							Dimensions.appendChild(Height);

							Element Width = doc.createElement("Width");
							Width.appendChild(doc.createTextNode(String.valueOf(j)));
							Dimensions.appendChild(Width);

							Element Length = doc.createElement("Length");
							Length.appendChild(doc.createTextNode(String.valueOf(j)));
							Dimensions.appendChild(Length);

							Element Weights = doc.createElement("Weights");
							Attr UOMWeight = doc.createAttribute("UOM");
							UOMWeight.setValue("PG");
							Weights.setAttributeNode(UOMWeight);
							Package.appendChild(Weights);

							Element Weight = doc.createElement("Weight");

							Weight.appendChild(doc.createTextNode(String.valueOf(j)));

							Weights.appendChild(Weight);
							Packages.appendChild(Package);
						}						
						}
							
				

						// DigitalAssets

						Element DigitalAssets = doc.createElement("DigitalAssets");
						Item.appendChild(DigitalAssets);

						Element DigitalFileInformation = doc.createElement("DigitalFileInformation");
						Attr DigitalFileInformationMaintenanceType = doc.createAttribute("MaintenanceType");
						DigitalFileInformationMaintenanceType.setValue("A");
						DigitalFileInformation.setAttributeNode(DigitalFileInformationMaintenanceType);
						Attr AssetID = doc.createAttribute("AssetID");
						AssetID.setValue(PartNo + i);
						DigitalFileInformation.setAttributeNode(AssetID);
						Attr DigitalFileInformationLanguageCode = doc.createAttribute("LanguageCode");
						DigitalFileInformationLanguageCode.setValue("FR");
						DigitalFileInformation.setAttributeNode(DigitalFileInformationLanguageCode);
						DigitalAssets.appendChild(DigitalFileInformation);

						Element FileName = doc.createElement("FileName");
						FileName.appendChild(doc.createTextNode(PartNo + i + "." + ImageExt.toLowerCase()));
						DigitalFileInformation.appendChild(FileName);

						Element AssetType = doc.createElement("AssetType");
						AssetType.appendChild(doc.createTextNode("P04"));
						DigitalFileInformation.appendChild(AssetType);

						Element FileType = doc.createElement("FileType");
						FileType.appendChild(doc.createTextNode(ImageExt.toUpperCase()));
						DigitalFileInformation.appendChild(FileType);

						Element Representation = doc.createElement("Representation");
						Representation.appendChild(doc.createTextNode("A"));
						DigitalFileInformation.appendChild(Representation);

						Element FileSize = doc.createElement("FileSize");
						FileSize.appendChild(doc.createTextNode("1234"));
						DigitalFileInformation.appendChild(FileSize);

						Element Resolution = doc.createElement("Resolution");
						Resolution.appendChild(doc.createTextNode("72"));
						DigitalFileInformation.appendChild(Resolution);

						Element ColorMode = doc.createElement("ColorMode");
						ColorMode.appendChild(doc.createTextNode("RGB"));
						DigitalFileInformation.appendChild(ColorMode);

						Element Background = doc.createElement("Background");
						Background.appendChild(doc.createTextNode("WHI"));
						DigitalFileInformation.appendChild(Background);

						Element OrientationView = doc.createElement("OrientationView");
						OrientationView.appendChild(doc.createTextNode("xxx"));
						DigitalFileInformation.appendChild(OrientationView);

						Element AssetDimensions = doc.createElement("AssetDimensions");
						Attr AssetDimensionsUOM = doc.createAttribute("UOM");
						AssetDimensionsUOM.setValue("PX");
						AssetDimensions.setAttributeNode(AssetDimensionsUOM);
						DigitalFileInformation.appendChild(AssetDimensions);

						Element AssetHeight = doc.createElement("AssetHeight");
						AssetHeight.appendChild(doc.createTextNode("250"));
						AssetDimensions.appendChild(AssetHeight);

						Element AssetWidth = doc.createElement("AssetWidth");
						AssetWidth.appendChild(doc.createTextNode("250"));
						AssetDimensions.appendChild(AssetWidth);

						Element FilePath = doc.createElement("FilePath");
						FilePath.appendChild(doc.createTextNode("http://www.autocare.org"));
						DigitalFileInformation.appendChild(FilePath);

						Element URI = doc.createElement("URI");
						URI.appendChild(doc.createTextNode("http://www.autocare.org"));
						DigitalFileInformation.appendChild(URI);

						Element AssetDates = doc.createElement("AssetDates");
						DigitalFileInformation.appendChild(AssetDates);

						Element AssetDate = doc.createElement("AssetDate");
						Attr assetDateType = doc.createAttribute("assetDateType");
						assetDateType.setValue("MOD");
						AssetDate.setAttributeNode(assetDateType);
						AssetDate.appendChild(doc.createTextNode("2016-07-15"));
						AssetDates.appendChild(AssetDate);

						Element Country = doc.createElement("Country");
						Country.appendChild(doc.createTextNode("US"));
						DigitalFileInformation.appendChild(Country);

						// Trailer
						Element Trailer = doc.createElement("Trailer");
						PIES.appendChild(Trailer);

						Element ItemCount = doc.createElement("ItemCount");
						ItemCount.appendChild(doc.createTextNode("1"));
						Trailer.appendChild(ItemCount);

						Element TransactionDate = doc.createElement("TransactionDate");
						TransactionDate.appendChild(doc.createTextNode("2019-12-27"));
						Trailer.appendChild(TransactionDate);

						// write the content into xml file
						TransformerFactory transformerFactory = TransformerFactory.newInstance();
						Transformer transformer = transformerFactory.newTransformer();
						DOMSource source = new DOMSource(doc);
						StreamResult result = new StreamResult(
								new File(PIESdic+"\\" + PartNo + i + ".xml"));
						transformer.setOutputProperty(OutputKeys.INDENT, "yes");
						transformer.transform(source, result);
						/*
						// Output to console for testing
						StreamResult consoleResult = new StreamResult(System.out);
						transformer.transform(source, consoleResult);
						*/
					}
				 catch (Exception e) {
					e.printStackTrace();
				}
			}
			System.out.println("*****Xml file is created succesfully*****");
		} else {

			System.out.println(
					"\nXML creation failed \n Check possible reason:\n 1.ZZ1 price is higher then RET Price \n or/and \n 2.Invalid Asset Extenstion \n 3.EA package is mandatory \n 4.Invalide package Type");

		}
		{
			main(new String[] {"hello"});
		}
	}
	
}
